﻿namespace BetaTester
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PostHash = new Label();
            Hasher = new Button();
            TextToHash = new TextBox();
            SuspendLayout();
            // 
            // PostHash
            // 
            PostHash.AutoSize = true;
            PostHash.Location = new Point(12, 77);
            PostHash.Name = "PostHash";
            PostHash.Size = new Size(59, 20);
            PostHash.TabIndex = 0;
            PostHash.Text = "Hashed";
            // 
            // Hasher
            // 
            Hasher.Location = new Point(27, 45);
            Hasher.Name = "Hasher";
            Hasher.Size = new Size(94, 29);
            Hasher.TabIndex = 1;
            Hasher.Text = "button1";
            Hasher.UseVisualStyleBackColor = true;
            Hasher.Click += Hasher_Click;
            // 
            // TextToHash
            // 
            TextToHash.Location = new Point(12, 12);
            TextToHash.Name = "TextToHash";
            TextToHash.Size = new Size(125, 27);
            TextToHash.TabIndex = 2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(TextToHash);
            Controls.Add(Hasher);
            Controls.Add(PostHash);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label PostHash;
        private Button Hasher;
        private TextBox TextToHash;
    }
}
