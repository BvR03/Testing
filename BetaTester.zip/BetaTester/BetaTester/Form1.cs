using System.Security.Cryptography;
using System.Text;
namespace BetaTester

{
    public partial class Form1 : Form

    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Hasher_Click(object sender, EventArgs e)
        {
            string text = TextToHash.Text;
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(text);
                byte[] hashBytes = sha256.ComputeHash(bytes);

                StringBuilder hashBuilder = new StringBuilder();
                foreach (byte b in hashBytes)
                    hashBuilder.Append(b.ToString("x2"));

                string hash = hashBuilder.ToString();
                PostHash.Text = hash;
            }
        }
    }
}
